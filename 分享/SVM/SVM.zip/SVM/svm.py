from sklearn.svm import SVC
from sklearn import datasets
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import os

mpl.rc('axes', labelsize=14)
mpl.rc('xtick', labelsize=12)
mpl.rc('ytick', labelsize=12)

# Where to save the figures
PROJECT_ROOT_DIR = "."
CHAPTER_ID = "svm"
IMAGES_PATH = os.path.join(PROJECT_ROOT_DIR, "images", CHAPTER_ID)
os.makedirs(IMAGES_PATH, exist_ok=True)

def save_fig(fig_id, tight_layout=True, fig_extension="png", resolution=300):
    path = os.path.join(IMAGES_PATH, fig_id + "." + fig_extension)
    print("Saving figure", fig_id)
    if tight_layout:
        plt.tight_layout()
    plt.savefig(path, format=fig_extension, dpi=resolution)

#获取鸢尾花数据
iris = datasets.load_iris()
X = iris["data"][:, (2, 3)]  #选择全部案例，并选择其中两种特征
y = iris["target"]#标签

setosa_or_versicolor = (y == 0) | (y == 1)#将鸢尾花分成两类 所得的结果为一个索引
X = X[setosa_or_versicolor]
y = y[setosa_or_versicolor]

# SVM 分类器
svm_clf = SVC(kernel="linear", C=float("inf"))#核函数（线性核函数、高斯核函数）
svm_clf.fit(X, y)#获得w,b

#训练操作完成

#绘制图像
x0 = np.linspace(0, 5.5, 200)#x轴
#传统 线性回归、逻辑回归模型
pred_1 = 5*x0 - 20
pred_2 = x0 - 1.8
pred_3 = 0.1 * x0 + 0.5

#绘制所得划分超平面  w0x0+w1x1+b=0
def plot_svc_decision_boundary(svm_clf, xmin, xmax):
    w = svm_clf.coef_[0] #权重参数
    b = svm_clf.intercept_[0] #偏置参数

    # At the decision boundary, w0*x0 + w1*x1 + b = 0
    # => x1 = -w0/w1 * x0 - b/w1
    x0 = np.linspace(xmin, xmax, 200) # 取当前传入值最小与最大范围内的200个数
    decision_boundary = -w[0]/w[1] * x0 - b/w[1] #获得决策边界 此时x1=(-w0x0-b)/w1

    margin = 1/w[1] #当前边界到支持向量的距离  优化目标：最大化几何边距
    gutter_up = decision_boundary + margin #超平面向上一点的曲线  当前的决策边界+几何距离
    gutter_down = decision_boundary - margin #超平面向下一点的曲线  当前的决策边界-几何距离

    # 获得所有的支持向量 , 用散点图表示支持向量
    svs = svm_clf.support_vectors_
    plt.scatter(svs[:, 0], svs[:, 1], s=180, facecolors='#FFAAAA')
    plt.plot(x0, decision_boundary, "k-", linewidth=2)#绘制当前决策边界
    plt.plot(x0, gutter_up, "k--", linewidth=2)
    plt.plot(x0, gutter_down, "k--", linewidth=2)

fig, axes = plt.subplots(ncols=2, figsize=(10,2.7), sharey=True)

plt.sca(axes[0])
#绘制传统模型图
plt.plot(x0, pred_1, "g--", linewidth=2)
plt.plot(x0, pred_2, "m-", linewidth=2)
plt.plot(x0, pred_3, "r-", linewidth=2)
plt.plot(X[:, 0][y==1], X[:, 1][y==1], "bs", label="Iris versicolor")
plt.plot(X[:, 0][y==0], X[:, 1][y==0], "yo", label="Iris setosa")
plt.xlabel("Petal length", fontsize=14)
plt.ylabel("Petal width", fontsize=14)
plt.legend(loc="upper left", fontsize=14)
plt.axis([0, 5.5, 0, 2])

#绘制SVM分类图
plt.sca(axes[1])
plot_svc_decision_boundary(svm_clf, 0, 5.5)
plt.plot(X[:, 0][y==1], X[:, 1][y==1], "bs")#绘制数据点
plt.plot(X[:, 0][y==0], X[:, 1][y==0], "yo")
plt.xlabel("Petal length", fontsize=14)
plt.axis([0, 5.5, 0, 2])

save_fig("large_margin_classification_plot")
plt.show()


